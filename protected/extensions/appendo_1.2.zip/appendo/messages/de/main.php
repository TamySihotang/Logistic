<?php
/**
 * German translation of JAppendo.
 *
 * @author Stefan Volkmar <volkmar_yii@email.de> 
 * @package jappendo.messages.de
 * @since 0.2
 * @uses YiiFramework 1.1.6
 */

return array(
    'viewName must be set!' => 'Property "viewName" muss eine Wert haben',
    'ID of the HTML-element must be set!' => 'Die ID des HTML-Elemenetes muss einen Wert haben',
);
?>
